// Create button values dynamically using createElement and appendChild
const buttonsContainer = document.querySelector("#buttons-container");
const display = document.querySelector("#display");

const buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', 'C', '+',
    '='
];

// Dynamically create buttons
buttons.forEach(char => {
    const btn = document.createElement('button');
    btn.textContent = char;

    if (char === 'C') {
        btn.classList.add('clear');
    } else if (char === '=') {
        btn.classList.add('equals');
    } else if (['/', '*', '-', '+'].includes(char)) {
        btn.classList.add('operator');
    }

    btn.addEventListener('click', () => handleClick(char));
    buttonsContainer.appendChild(btn);
});

let currentInput = '';

function handleClick(value) {
    if (value === 'C') {
        currentInput = '';
        updateDisplay('0');
    } else if (value === '=') {
        try {
            const result = eval(currentInput);
            updateDisplay(result);
            currentInput = result.toString();
        } catch {
            updateDisplay("Error");
            currentInput = '';
        }
    } else {
        currentInput += value;
        updateDisplay(currentInput);
    }
}

function updateDisplay(val) {
    display.textContent = val;
}
